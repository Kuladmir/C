#include<stdio.h>
#include<Windows.h>
#include<mmsystem.h>
#pragma comment(lib, "winmm.lib")
void music(const char* music_name, bool repeat = false, int volume = -1)
{
	char str[100] = "";
	sprintf(str, "open %s alias bgm", music_name);
	mciSendString(str, NULL, 0, NULL);
	sprintf(str, "play bgm %s", repeat ? "repeat" : "");
	mciSendString(str, NULL, 0, NULL);
	if (volume != -1)
	{
		sprintf(str, "setaudio bmg volume to %d", volume);
		mciSendString(str, NULL, 0, NULL);
	}
}
int main()
{
	music("D:\\collect\\2354335626.mp3", true, 50);
	getchar();
	return 0;
}