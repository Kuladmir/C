#include<stdio.h>
#include<easyx.h>
#include<time.h>

#define pic_num 4 //���嶯����ͼƬ������
#define FPS 400 //����ͼƬ�л������ms

int main()
{
	initgraph(200, 200,EX_SHOWCONSOLE);
	setbkcolor(YELLOW);
	cleardevice();	
	int i = pic_num;
	char path[50];
	IMAGE pic[pic_num];
	for (i = 0; i < pic_num; i++)
	{
		sprintf(path, "diamond%d.png", i + 1);
		loadimage(pic + i, path, 30, 30);
	}
	const clock_t sd_time = 1000 / 60;
	int index = 0;
	int start_time = 0;
	int end_time = 0;
	int fream_time = 0;

	while (true)
	{		
		start_time = clock();
		BeginBatchDraw();
		cleardevice();
		putimage(50, 50, pic + index);
		EndBatchDraw();
		index = (clock() / FPS) % pic_num;
		end_time = clock() - start_time;
		if(end_time  < sd_time)
		{
			Sleep(sd_time-end_time);
		}
	}
	getchar();
	return 0;
}