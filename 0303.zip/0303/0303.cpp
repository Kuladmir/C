#include<stdio.h>
#include<time.h>
#include<easyx.h>
#define frame 7  //����ͼ��֡��
#define size 60 //����ͼ�ﵥ��ͼ�Ĵ�С
#define height 67 //����ͼ�ﵥ��ͼ�ĸ߶�
#define FPS 200 //ÿ200 ms�޸�һ��
int main()
{
	initgraph(200, 200, EX_SHOWCONSOLE);
	setbkcolor(LIGHTBLUE);
	cleardevice();	

	IMAGE img_spirit;
	loadimage(&img_spirit, "test.jpg");

	int start_time = 0;
	int end_time = 0;
	int index = 1;
	const clock_t sd_time = 1000 / 60;

	while (true)
	{
		start_time = clock(); 
		BeginBatchDraw();
		cleardevice();
		putimage(10, 10, size, height, &img_spirit, index*size,0);
		EndBatchDraw();
		index = (clock() / FPS) % frame;
		end_time = clock() - start_time;
		if (end_time < sd_time)
		{
			Sleep(sd_time-end_time);
		}
	}
	return 0;
}